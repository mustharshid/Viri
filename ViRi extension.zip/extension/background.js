import { decryptData } from './utils/crypto.js';

// Setup listener for PWA to connect to the extension
chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  if (request.action === 'VERIFY_TRANSFER') {
    handleVerification(request.payload)
      .then(result => sendResponse({ success: true, data: result }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    
    // Return true to indicate we wish to send a response asynchronously
    return true;
  }
});

/**
 * Handles the bank verification flow.
 * 1. Pulls credentials from IndexedDB.
 * 2. Connects to bank endpoint.
 * 3. Finds matching transaction.
 */
async function handleVerification(payload) {
  const { amount, bank, accountId } = payload;
  
  // NOTE: In a real environment, we'd fetch the encrypted TOTP seed from IndexedDB,
  // decrypt it, generate the 6-digit code, and submit the login request.
  console.log(`[Viri Bridge] Starting verification for ${bank} on account ${accountId} for amount ${amount}`);
  
  // Simulate network delay and Bank API Call
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Simulated match
  // To avoid lockout loops, this should only happen purely on-demand.
  return {
    status: 'CREDITED',
    reference: `${bank}-${Math.floor(Math.random() * 1000000)}`,
    amount: amount,
    timestamp: new Date().toISOString()
  };
}

// Modify Headers to bypass CORS for specific Bank API calls if needed
chrome.declarativeNetRequest.updateDynamicRules({
  addRules: [
    {
      id: 1,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "Origin", operation: "remove" },
          { header: "Referer", operation: "remove" }
        ],
        responseHeaders: [
          { header: "Access-Control-Allow-Origin", operation: "set", value: "*" }
        ]
      },
      condition: {
        urlFilter: "bankofmaldives.stoplight.io/*",
        resourceTypes: ["xmlhttprequest", "fetch"]
      }
    }
  ],
  removeRuleIds: [1]
});
